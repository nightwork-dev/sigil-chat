# @gonk/eve-host

Eve extension packaging plus small, application-owned helpers for binding a Gonk
principal, durable channel/persona identity, and an Eve session to one turn.

## What this package does

- Ships an Eve extension with a namespaced dynamic instruction contribution.
- Normalizes direct and MCP callers into one `AgentTurnEnvelope` (exported from
  `@gonk/eve-host/guard`).
- Provides a bound Eve channel that authenticates the caller, verifies
  application-owned principal/channel/persona/session records, and only then
  calls Eve's public `send` surface.
- Derives short-lived, resource-scoped delegations from that authorized turn
  for direct Gonk calls and authenticated HTTP MCP calls.

The extension's dynamic instruction is context projection only. It is not an
authorization boundary. The application owns ingress authentication, durable
binding and membership records, the delegation signer and revocation source,
and the mapping from an authorized Eve turn to its downstream MCP client.

```ts
import {
  createBoundEveChannel,
  createDelegatedMcpAuthenticator,
  createSignedDelegationProvider,
  makeDelegatedMcpAuthContext,
} from "@gonk/eve-host/guard";
```

`execution.eveSessionId` is durable identity. `execution.continuationToken` is
an opaque Eve resume credential; the channel never substitutes one for the
other. The channel also requires Eve's authenticated principal to equal the
guarded Gonk principal before it can send.

### Eve and the neutral execution binding

`@gonk/persona` deliberately knows nothing about Eve. At the Eve-host boundary,
`EveMemoryHost` accepts the trusted `eveSessionId` from an authorized Eve turn
and writes it to the persona contract as `executionSessionId`. The value is the
same durable execution identity, but the neutral field lets other hosts make
the same immutable binding without inheriting Eve vocabulary. Eve's
`continuationToken` remains a separate opaque resume credential and is never
stored as the execution binding.

`onAuthorizedTurn` is the application seam for calling
`provider.issueForTurn(envelope, ...)` and placing the resulting bearer where
that turn's Eve-to-Gonk MCP connection can use it. The HTTP authenticator reads
the bearer from the real `Authorization` header, while
`makeDelegatedMcpAuthContext` revalidates it for discovery and every tool call.
No caller identity is accepted from tool input or an unsigned header.

These helpers prove transport authentication and Gonk authorization parity.
They do not implement an interactive approval or human-in-the-loop channel;
that remains a separate host policy and UI concern.

## Mounting

```ts
// agent/extensions/gonk.ts
export { default } from "@gonk/eve-host";
```

Eve namespaces its contribution under the mount name. With the example above,
the instruction contribution is `gonk__identity`.

## Version support

This spike is built and clean-room checked against Eve 0.25.2. `eve` remains a
peer dependency so the consuming agent supplies the runtime.
