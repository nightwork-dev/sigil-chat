import { defineDynamic } from "eve/instructions";
import { defineInstructions } from "eve/instructions";

// Projection only. The consuming channel authorizes before it calls Eve.
export default defineDynamic({
  events: {
    "session.started": () => defineInstructions({ markdown: "This agent may use only host-authorized Gonk context." }),
  },
});
