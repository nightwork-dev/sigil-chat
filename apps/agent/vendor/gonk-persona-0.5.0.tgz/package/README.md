# @gonk/persona

Two things live here, and the second is why the package is called *persona* and
not *agent*:

1. A **persona registry** over markdown files (AGENTS.md spec) — identity,
   active-persona resolution, and the tools an agent calls to list/switch/define.
2. A **self-model** — the durable interiority beneath that identity: what a
   persona believes about itself, about the people it works with, and about how
   it should behave on *this* substrate. This is the layer that lets a persona
   *become someone over time* instead of re-reading a character sheet each session.

The registry is the skeleton; the self-model is the part that grows.

---

## Part 1 — the registry

### Persona shape

Intentionally minimal — `id`, `name?`, `description?`, `systemPrompt?`. Plugins
(TTS, memory, notes, …) extend by writing namespaced keys (`tts.*`, `memory.*`)
into the persona scope, **not** by mutating the persona record.

### Storage

Personas are markdown files with YAML frontmatter; the body is the system prompt
(unless `systemPrompt:` frontmatter overrides):

```markdown
---
id: alice
name: Alice
description: Architect
---
You are Alice. ...
```

- Roots named `agents/` or `.agents/` hold persona files directly (`agents/<id>.md`).
- All other roots hold them at `<root>/agents/<id>.md`, so `.claude/agents/alice.md`
  is found by both Claude Code and gonk.

A persona's **home** is the directory next to its file (`agents/alice/`). Plugin
sidecar data — the self-model, the portrait, tts config — lives there. The home
*is* the persona-scope binding.

### Active resolution

`active.persona` is a normal scope key, read narrowest-first (session → directory
→ project → global, skipping the persona tier itself, which would be circular).
The resolved id's home becomes the persona-scope binding for the turn.

```ts
import { bootstrapScope } from "@gonk/persona/active";
import { PersonaRegistry } from "@gonk/persona/registry";

const reg = new PersonaRegistry({ cwd: process.cwd() });
const { scope, activePersona } = bootstrapScope(
  { cwd: process.cwd() },
  (id) => reg.get(id)?.location.home,
);
```

### Immutable execution binding

`PersonaExecutionBinding` fixes the persona, authored base, channel, and
`executionSessionId` selected by trusted host code for one execution. The
binding is frozen on creation: a later mutable active-persona pointer cannot
replace it for that same execution, while a different execution receives a
separate binding. This is deliberately host-neutral; hosts translate their own
session identity into `executionSessionId` at their boundary.

### Portrait & cross-host portability

A persona may carry its own face — a persona-tier blob at `portrait.png` under
the home's `blobs/` dir; `registry.portraitFor(id)` returns its `BlobHandle`, and
`list_personas`/`current_persona` surface `portraitPath` so a visual host can
render it. `exportHome(id, destDir)` / `importHome(bundleDir, …)` round-trip a
persona's whole home (definition + self-model + portrait + tts) across hosts, so
a persona defined under one harness is discoverable on another without re-`define`.

### Tools

`personaTools({ registry })` returns five `ToolDefinition`s: `list_personas`,
`current_persona`, `switch_persona`, `define_persona`, `delete_persona`. Wired
identically into Pi (`pi-persona`), the CLI, and Claude Code (`claude-persona`),
so a self-model claim authored under one host is read back under another.

---

## Part 2 — the self-model

A persona's durable interiority lives in `SelfModelStore`, over the **persona**
scope tier (so it is per-persona automatically). It is the substrate beneath
taste, a theory of the people the persona works with, and substrate-aware
metacognition. See [`docs/persona-self-model-design.md`](../../../docs/persona-self-model-design.md),
[`docs/cultivation-driver-design.md`](../../../docs/cultivation-driver-design.md),
and [`docs/person-modeling-design.md`](../../../docs/person-modeling-design.md).

### An entry

Each claim is a small, falsifiable record:

| Field | What it is |
|---|---|
| `face` | **what the claim is about**: `self` (own taste/moves), `user` (a collaborator), `relationship` (the two together). Open axis — the store never branches on it. |
| `claim` | a falsifiable statement, written so later experience can confirm or break it |
| `status` | `provisional` → `confirmed` / `broken` (time is the verifier), plus **`aspirational`** ("who I want to become" — approached, not confirmed) |
| `visibility` | `private` vs `shared`, stored under **separate keys** — a shared read structurally cannot surface a private entry |
| `confidence` | 0..1, how strongly the persona currently holds it |
| `activates` | *when* a claim surfaces — `"always"` (pinned) or trigger phrases |
| `condition?` | *under which substrate* it holds — `{ model?, provider? }`; absent = substrate-independent |
| `expiresAt?` | present marks a **momentary state** (decays); absent = a durable **trait** |
| `subject?` | for `user`/`relationship` faces, who it is about |

### Two structural guarantees

- **Privacy is a key split, not a filter.** Private and shared entries live under
  different scope keys; a `shared` read cannot return a `private` entry even by
  mistake. (The trust boundary for the *raw store handle* is the scope tier — the
  persona home — not the split.)
- **Time is the verifier.** A claim is held provisionally and confirmed/broken by
  what later sessions reveal — never scored by a judge. `aspirational` is held
  *out* of that machinery (`isDescriptiveStatus` gates it): an aspiration is
  evaluated by movement toward it, not by confirmation. The `mark()` path enforces
  this — it refuses to confirm/break an aspiration.

### Traits vs. state (person-modeling)

The same store models *who you are* and *who you are right now*:

```
  TRAIT  (durable)        STATE  (momentary, expiresAt)
  ─────────────────       ────────────────────────────
  "prefers deletion       "running on empty tonight"
   over abstraction"       → decays; listActiveStates()
  never expires            excludes it once stale
```

`listActiveStates({ now })` returns only states still live at `now` — a stale
state is **structurally unreadable**, so the agent never adapts to a mood that
has already passed. This is the seat of state-detection; the *signal* comes from
`@gonk/traces` (below).

### The cultivation surface (pure decision functions)

These are the behaviors the cultivation driver composes. They are **pure
functions with injected dependencies** — the logic is here; the host wires the
IO that fires them.

- **`matchesCondition(condition, substrate)`** — does a claim hold on the current
  model/provider? Absent condition always matches.
- **`biasRecallForSubstrate(entries, substrate, weak?)`** + **`evidenceCanSettle(...)`**
  — *cross-model recall*: on a substrate that's weak for the task, down-weight
  claims conditioned on it (surface as *caution*), up-weight ones formed when
  stronger; and a claim is confirmed/broken only by **matching-substrate**
  evidence. "I know what I'm running on; when it's weak, I lean on what I learned
  when I was stronger."
- **`routeDeclaredClaim(attribution)`** — the *subject-authority* rule: a
  first-party statement updates the speaker's own `user` model; a **third-party**
  claim about someone else writes the *speaker's* `relationship` face, **never**
  the target's model; an unattributed claim writes nothing to `user`. This is the
  structural defense against model-poisoning (a `SubjectRef` seam is in place for
  the deferred multi-user case).
- **`shouldElicit(inputs)`** — the *elicit trigger*: ask the user how they like a
  task done only when **all four** hold — un-recipe'd (hard gate), preference-laden,
  recurring, costly-to-get-wrong — under a per-session budget, with a per-task-type
  bar **derived from the persona's own trace cohort + win/reversal signal** (not a
  constant; it gets reticent if brushed off, forthcoming when questions land).
- **`connectiveRecall({ workSummary, recalledItems, auxClient, bar })`** — mid-work,
  surface non-obvious links between the current work and the user's stated
  goals/values; a precision bar (also win/reversal-tuned) keeps it signal, not spam.

---

## How it all connects

The self-model is the **store**; three sibling capabilities feed and act on it.

![The self-model loop — traces (signal) feeds self-model-reflector (the write-pass), which writes persona's self-model (the model); an actionable connection becomes a work item (acting on it). Declared input enters persona through subject-authority routing.](../../../docs/diagrams/self-model-loop.svg)

Read it as one loop:

1. **`@gonk/traces`** records what actually happened each turn — now including the
   **model/provider** that produced it and extractable **text-state features**.
   This is the ground truth everything else tunes on (no magic constants).
2. **`@gonk/self-model-reflector`** runs on idle / PreCompact, reads a recent
   transcript, and proposes self-model deltas through an audit gate — moving the
   "is this durable?" judgment out of the task-focused moment. It confirms a
   conditioned claim only when the run's substrate matches.
3. **`@gonk/persona`** holds the result and exposes the cultivation decision
   functions. Declared input enters through subject-authority routing; recall is
   substrate-biased; connective recall surfaces links while working.
4. **`@gonk/work-items`** is where an *actionable* connection goes — a goal worth
   pursuing becomes a supervised work item, and anything needing your call waits
   in a durable inbox.

The through-line: **traces = signal, reflector = the write-pass, persona = the
model, work-items = acting on it** — with the self-model the shared spine.

---

## Entry points

```ts
import { PersonaRegistry, personaTools, bootstrapScope } from "@gonk/persona";
import {
  SelfModelStore,
  isAlwaysActivation, parseActivationPhrases, matchesCondition,
  isDescriptiveStatus, isAspirational,
  routeDeclaredClaim, applyDeclaredClaim, isUnattributed,
  biasRecallForSubstrate, evidenceCanSettle,
  connectiveRecall, deriveConnectionBar,
  shouldElicit, deriveElicitBar, elicitPropensity,
} from "@gonk/persona";
import type { Persona } from "@gonk/persona/types";          // types only
```

## Where this is

The **registry and the self-model store are shipped and live** on all three hosts
— a claim authored under Pi is read under Claude Code. The reflector write-pass
is wired (`@gonk/self-model-reflector` + the host reflectors). The **cultivation
decision functions are built, tested, and cross-model-reviewed**, but pure — they
await the host wiring that fires them in a live turn (the elicit prompt, the
connective surface). Deliberately deferred: **multi-user / many-agent** modeling,
which needs a verified-identity layer (you cannot safely model *which person* a
claim is about until people are cryptographically distinguishable) — it rides the
connectivity tier when a real consumer appears.
